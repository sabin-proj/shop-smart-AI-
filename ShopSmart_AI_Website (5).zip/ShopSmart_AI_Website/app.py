from flask import Flask, render_template, request, jsonify
from pathlib import Path
import pickle
import Orange

app = Flask(__name__)
MODEL_PATH = Path(__file__).with_name('shopsmart_model.pkcls')

def get_model():
    if not MODEL_PATH.exists():
        return None
    with MODEL_PATH.open('rb') as f:
        return pickle.load(f)

@app.get('/')
def home():
    return render_template('index.html', connected=MODEL_PATH.exists())

@app.post('/predict')
def predict():
    try:
        model = get_model()
        if model is None:
            return jsonify(error='Place shopsmart_model.pkcls in the website folder first.'), 503
        answers = request.get_json(force=True)
        attrs = list(model.domain.attributes)
        row = []
        for attr in attrs:
            if attr.name not in answers:
                return jsonify(error=f'Missing field: {attr.name}'), 400
            val = answers[attr.name]
            if attr.is_discrete:
                val = str(val)
                if val not in attr.values:
                    return jsonify(error=f'Invalid value for {attr.name}: {val}. Expected: {", ".join(attr.values)}'), 400
            else:
                val = float(val)
            row.append(val)
        data = Orange.data.Table.from_list(Orange.data.Domain(attrs), [row])
        result = model(data)
        return jsonify(decision=str(result[0]))
    except Exception as exc:
        return jsonify(error=str(exc)), 400

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000)
